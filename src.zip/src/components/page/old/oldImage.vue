<template>
    <div style="margin-left:240px;margin-top:14px">
        <h1 style="margin-left:217px">老人年龄分析图</h1><br>
        <img :src=url width="700" height="500" v-image-preview/>
    </div>
</template>
<script src="https://cdn.staticfile.org/jquery/1.10.2/jquery.min.js"></script>

<script>
var image = localStorage.getItem("oldImage")
// console.log(222)
// console.log(image)
export default{
    data(){
        
        return{
            url : "http://127.0.0.1:5000/static/image/oldAna.png"
            //  url:"https://fuss10.elemecdn.com/e/5d/4a731a90594a4af544c0c25941171jpeg.jpeg"  
        }
    }
}
</script>
