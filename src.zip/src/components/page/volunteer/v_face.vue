<template>
    <div>
          <img src="http://127.0.0.1:5001/faceCollectvol">
    </div>
</template>