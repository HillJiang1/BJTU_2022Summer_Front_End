<template>
  <div id="app">
    <!-- <img src="./assets/logo.png"> -->
    <router-view/><router-view/>
  </div>
</template>

<script>

</script>

<style>
  @import "./assets/css/main.css";
  @import "./assets/css/color-dark.css";
</style>
